<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Welcome to Jahangir Web</title>

<style>
    body {
        margin: 0;
        padding: 0;
        background: linear-gradient(135deg, #000000, #003d2e);
        font-family: Poppins, sans-serif;
        color: white;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .box {
        text-align: center;
        padding: 40px;
        background: rgba(255,255,255,0.08);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        border: 2px solid rgba(0,255,180,0.4);
        box-shadow: 0 0 25px rgba(0,255,160,0.5);
        animation: fade 1.5s ease-in-out;
        width: 85%;
        max-width: 450px;
    }

    @keyframes fade {
        from { opacity: 0; transform: scale(0.9); }
        to   { opacity: 1; transform: scale(1); }
    }

    h1 {
        font-size: 32px;
        margin-bottom: 10px;
        text-shadow: 0 0 10px #00ffb3;
    }

    p {
        font-size: 18px;
        opacity: 0.9;
        margin-bottom: 20px;
    }

    .btn {
        display: inline-block;
        padding: 14px 25px;
        background: #00ffb3;
        color: black;
        font-weight: bold;
        border-radius: 8px;
        text-decoration: none;
        font-size: 18px;
        box-shadow: 0 0 15px #00ffb3;
        transition: 0.3s;
    }

    .btn:hover {
        background: #00ffc9;
        box-shadow: 0 0 30px #00ffb3;
    }

</style>
</head>

<body>

<div class="box">
    <h1>WELCOME TO WEB</h1>
    <p>Beautiful PHP Landing Page Designed for Jahangir.</p>

    <a href="#" class="btn">Explore Now</a>
</div>

</body>
</html>
